<?php

/*
 * Plugin Name: Jitu Global Staffing Application Form
 * Plugin URI: https://www.zohocrm.com/plugins/Jitu-Global-Staffing-Application-Form
 * Description: This plugin allows you to create a Jitu Global Staffing Application Form in Zoho CRM.
 * Author: Jitu
 * Author URI: https://www.zohocrm.com/plugins/Jitu-Global-Staffing-Application-Form
 * Version: 1.0.0
 * Compatible with Zoho CRM versions: 7.0.0
 * Compatible with PHP versions: 5.2.4
 */

 namespace JituGlobalStaffing;

 if (!defined('ABSPATH')) {
     exit;
 }
 
 class JituGlobalStaffing {
     private $admin;
     private $db;
 
     public function __construct() {
         $this->define_constants();
         $this->include_files();
         $this->init_classes();
         $this->setup_hooks();
     }
 
     private function define_constants() {
         define('JGS_PLUGIN_NAME', 'Jitu Global Staffing Application Form');
         define('JGS_PLUGIN_VERSION', '1.0.0');
         define('JGS_PLUGIN_AUTHOR', 'Jitu');
         define('JGS_PLUGIN_AUTHOR_URI', 'https://www.zohocrm.com/plugins/Jitu-Global-Staffing-Application-Form');
         define('JGS_PLUGIN_DIR_URL', plugin_dir_url(__FILE__));
         define('JGS_PLUGIN_DIR_PATH', plugin_dir_path(__FILE__));
         define('JGS_PLUGIN_BASENAME', plugin_basename(__FILE__));
     }
 
     private function include_files() {
         require (JGS_PLUGIN_DIR_PATH . 'admin/ui/class-dashboard.php');
         require (JGS_PLUGIN_DIR_PATH . 'admin/database/class-init.php');
         require (JGS_PLUGIN_DIR_PATH . 'admin/database/class-data.php');
         require (JGS_PLUGIN_DIR_PATH . 'admin/index.php');
         require (JGS_PLUGIN_DIR_PATH . 'form.php');
     }
 
     private function init_classes() {
         if (class_exists('Admin\UI\Dashboard')) {
             $this->dashboard = new \Admin\UI\Dashboard();
         }
         if (class_exists('Admin\Database\Init')) {
             $this->db = new \Admin\Database\Init();
         }
         if (class_exists('Admin\Database\Data')) {
             $this->data = new \Admin\Database\Data();
         }
         if (class_exists('Admin\JGSZoho\Admin')) {
             $this->admin = new \Admin\JGSZoho\Admin();
         }

         if(class_exists('Admin\Zoho\WP_Admin_Calls\ZohoData')){
             $this->zoho = new \Admin\Zoho\WP_Admin_Calls\ZohoData();
         }
     }
 
     private function setup_hooks() {
         add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
         add_shortcode('jitu_global_staffing', [$this, 'render_form']);
         add_filter('cron_schedules', [$this, 'custom_cron_schedules']);
         add_action('jgs_test_cron_job', [$this, 'run_test_success']);
 
         register_activation_hook(__FILE__, [$this, 'activate']);
         register_deactivation_hook(__FILE__, [$this, 'deactivate']);
     }
 
     public function enqueue_assets() {
         if (is_page('jitu-staffing-job-application-form')) {
             wp_enqueue_style('zf-css', JGS_PLUGIN_DIR_URL . 'css/style.css', [], JGS_PLUGIN_VERSION);
             wp_enqueue_script('zf-js', JGS_PLUGIN_DIR_URL . 'js/scripter.js', ['jquery'], JGS_PLUGIN_VERSION, true);
         }
     }
 
     public function render_form($atts, $content = null) {
         return form();
     }
 
     public function custom_cron_schedules($schedules) {
         $schedules['every_minute'] = [
             'interval' => 60,
             'display'  => esc_html__('Every Minute')
         ];
         return $schedules;
     }
 
     public function run_test_success() {
         $this->zoho->fetchCandidates();
     }
 
     public function activate() {
        if ($this->db) {
            $this->db->installDb();
        }
         if (!wp_next_scheduled('jgs_test_cron_job')) {
             wp_schedule_event(time(), 'every_minute', 'jgs_test_cron_job');
         }
     }
 
     public function deactivate() {
        if ($this->db) {
            $this->db->uninstallDb();
        }
         $timestamp = wp_next_scheduled('jgs_test_cron_job');
         wp_unschedule_event($timestamp, 'jgs_test_cron_job');
     }
 }
 
 // Initialize the plugin
 new JituGlobalStaffing();