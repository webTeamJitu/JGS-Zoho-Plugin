<?php
namespace Admin\Database;

if (!defined('ABSPATH')) {
    exit;
}

class Init {
    private $table_name;

    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . "jgs";
    }

    public function installDb() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$this->table_name} (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            redirect_uri varchar(255) DEFAULT NULL,
            client_id varchar(255) DEFAULT NULL,
            client_secret varchar(255) DEFAULT NULL,
            refresh_token varchar(255) DEFAULT NULL,
            access_token varchar(255) DEFAULT NULL,
            expires_in int DEFAULT NULL,
            scope varchar(255) DEFAULT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);

        $this->seedData();
    }

    public function uninstallDb() {
        global $wpdb;
        $wpdb->query("DROP TABLE IF EXISTS {$this->table_name}");
    }

    private function seedData() {
        global $wpdb;

        $data = [
            'redirect_uri' => 'https://ba79-41-209-57-189.ngrok-free.app/zohoapi/gettoken',
            'client_id' => '1000.CWHP1B4K51EV9DDI41J1LYRVYWSN2I',
            'client_secret' => 'fa614f81a3dc7fe22848c4e4cedf41aa256e9901f8',
            'scope' => 'ZohoRecruit.modules.all',
            'refresh_token' => '1000.55767621209b1f2027071b51d4c0fd2a.2795750ba6c88da34b3ed25ebb878b1b'
        ];

        $wpdb->insert($this->table_name, $data);
    }
}