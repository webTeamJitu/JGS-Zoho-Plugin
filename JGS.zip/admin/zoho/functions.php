<?php

namespace Admin\Zoho\WP_Admin_Calls;

use Admin\Database\Data;

class ZohoData{
    private $accessToken;
    private $candidateId;
    private $apiURL;

    public function __construct(){
        include_once(plugin_dir_path(__DIR__) . 'database/class-data.php');
        $this->data = new Data();

        $this->accessToken = $this->get_access_token();
    }

    public function fetchCandidates(){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: Zoho-oauthtoken " . $this->accessToken,
        ]);
        $response = curl_exec($ch);
        curl_close($ch);

        $responseData = json_decode($response, true);

        error_log($responseData);
    }

}

?>
